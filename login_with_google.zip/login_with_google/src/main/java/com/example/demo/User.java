package com.example.demo;


import javax.validation.constraints.Email;

import org.antlr.v4.runtime.misc.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name="users")
public class User {
	
	 	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @Column(nullable = false)
	    private String name;

	    @Email
	    @Column(nullable = false)
	    private String email;

	    @Column(nullable = false)
	    private Boolean emailVerified = false;

	    @JsonIgnore
	    private String password;

	    @Enumerated(EnumType.STRING)
	    private Provider provider;
	 
	    public Provider getProvider() {
	        return provider;
	    }
	 
	    public void setProvider(Provider provider) {
	        this.provider = provider;
	    }

}
