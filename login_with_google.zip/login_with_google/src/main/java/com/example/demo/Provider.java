package com.example.demo;

public enum Provider {
	LOCAL, GOOGLE
}
