package com.example.demo;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface DefaultUserDetailsService extends UserDetailsService{

	User save(UserRegisterDTO userRegisterDTO);

	String generateOtp(User user);

	
}