package com.example.demo;

import java.util.List;
import java.util.Optional;

public interface ProductService {


	public List<Product> getProducts();
	public Product saveProduct(Product product);
	public Optional<Product> getProductById(Long id);
	
}

