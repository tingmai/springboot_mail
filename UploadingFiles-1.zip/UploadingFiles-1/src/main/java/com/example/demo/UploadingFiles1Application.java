package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadingFiles1Application {

	public static void main(String[] args) {
		SpringApplication.run(UploadingFiles1Application.class, args);
	}

}
