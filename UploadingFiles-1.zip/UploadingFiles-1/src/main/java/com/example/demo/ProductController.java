package com.example.demo;

import java.io.IOException;
import java.sql.Blob;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class ProductController {

	
	@Autowired
	private ProductService services;
	
	@GetMapping("/products")
	public String showIndex(Model model) {		
		model.addAttribute("products",services.getProducts());
		return "/products/index";
	}
	
	
	@GetMapping("/products/create")	
	public String showCreate(Model model) {
		model.addAttribute("product",new Product());
		return "/products/create";
	}
	
	@PostMapping("/save")
	public String saveProduct(@ModelAttribute("product") Product product, @RequestParam("file") MultipartFile file) throws IOException{
		
		String photo_name=file.getOriginalFilename();
		byte[] photo_data=file.getBytes();
		product.setPhoto_name(photo_name);
		product.setPhoto_data(photo_data);
		
		services.saveProduct(product);
		return "redirect:/products";
	}
	
	@GetMapping("/image")
	public void showImage(@RequestParam("id") Long id, HttpServletResponse response, Optional<Product> product) throws ServletException, IOException{
		product=services.getProductById(id);
		response.setContentType("image/jpeg,image/jpg,image/gif,image/pdf");
		response.getOutputStream().write(product.get().getPhoto_data());
		response.getOutputStream().close();
	}
	
	@GetMapping("/show")
	public String showDetails(Model model,@RequestParam Long id) {
		model.addAttribute("product",services.getProductById(id));
		return "products/details";
	}
	
	
	
	
}
