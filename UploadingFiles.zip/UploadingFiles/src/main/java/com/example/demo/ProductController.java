package com.example.demo;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class ProductController {

	@Autowired
	public ProductService services;
	
	@GetMapping("/products")
	public String showIndexPage(Model model) {
		model.addAttribute("products",services.list());
		return "products/index";
	}
	
	@GetMapping("/create")
	public String showCreatePage(Model model) {
		model.addAttribute("product",new Product());
		return "products/create";
	}
	
	@PostMapping("/save")
	public String saveProduct(@ModelAttribute("product") Product product,@RequestParam("file") MultipartFile file) throws IOException{
		
		String fileName=StringUtils.cleanPath(file.getOriginalFilename());
		product.setPhoto(fileName);
		
		Product saveProduct=services.saveProduct(product);
		
		//file upload process
		String uploadDir="./products-images/"+saveProduct.getId();
		product.setPhoto_path(uploadDir);
		
		Product UpdateProduct=services.saveProduct(product);
		Path uploadPath=Paths.get(uploadDir);
		
		if(!Files.exists(uploadPath)) {
			Files.createDirectories(uploadPath);
		}
		
			try(InputStream inputStream=file.getInputStream()){
				
				Path filePath=uploadPath.resolve(fileName);
				Files.copy(inputStream, filePath,StandardCopyOption.REPLACE_EXISTING);			
			}
			
			catch(IOException ex) {
				throw new IOException("Could not save image file"+fileName);
			}
		return "redirect:/products";
	}
}
