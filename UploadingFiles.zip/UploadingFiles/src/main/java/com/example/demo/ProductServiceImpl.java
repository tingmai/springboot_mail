package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	
	@Autowired
	private ProductRepo productRepo;
	
	@Override
	public List<Product> list() {
		// TODO Auto-generated method stub
		return productRepo.findAll();
	}

	@Override
	public Product saveProduct(Product p) {
		// TODO Auto-generated method stub
		return productRepo.save(p);
		
	}

	@Override
	public Product get(Long id) {
		// TODO Auto-generated method stub
		Optional<Product> opt=productRepo.findById(id);
		Product p=null;
		if(opt.isPresent()) {
			p=opt.get();
		}
		else {
			throw new RuntimeException("Product not found for id:"+id);
		}
		return p;
	}

	@Override
	public void destroy(Long id) {
		productRepo.deleteById(id);
		
	}
}
