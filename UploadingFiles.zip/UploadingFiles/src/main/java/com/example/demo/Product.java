package com.example.demo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name="products")
public class Product {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="price")
	private Double price;
	
	@Column(name="photo")
	private String photo;
	
	@Column(name="photo_path")
	private String photo_path;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



	public Double getPrice() {
		return price;
	}
	
	public void setPrice(Double price) {
		this.price = price;
	}


	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}




	public String getPhoto_path() {
		return photo_path;
	}

	public void setPhoto_path(String photo_path) {
		this.photo_path = photo_path;
	}


    

	public Product(long id, String name, Double price, String photo, String photo_path) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.photo = photo;
		this.photo_path = photo_path;
	}

	public Product() {
		super();
	}

	@Transient
	public String photo_full_path() {
		
		if(this.photo==null|| this.photo_path==null)
			return null;
		else
			return this.photo_path+"/"+this.photo;
	}
}
