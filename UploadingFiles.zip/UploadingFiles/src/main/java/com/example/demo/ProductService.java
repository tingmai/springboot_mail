package com.example.demo;

import java.util.List;

public interface ProductService {

	
	public List <Product> list();
	public Product saveProduct(Product p);
	public Product get(Long id);
	
	public void destroy(Long id);
	
}
