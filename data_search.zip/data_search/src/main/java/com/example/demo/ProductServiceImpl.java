package com.example.demo;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepo productRepo;
	
	@Override
	public Page<Product> listAll(int pageNum, String field, String type, String keyword) {
		Sort sort=Sort.by(field);
		Page <Product> products;
		
		sort=type.equals("asc")? sort.ascending():sort.descending();
		Pageable pageable=PageRequest.of(pageNum-1, 5,sort);
		
		if(keyword!=null) {
			products=productRepo.findAll(keyword, pageable);
		}
		else {
			products=productRepo.findAll(pageable);
			
			
		}
		return products;
	}

	@Override
	public Product saveProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepo.save(product);
	}

	@Override
	public Product getProduct(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Product> getProductById(Long id) {
		// TODO Auto-generated method stub
		Optional<Product> opt=productRepo.findById(id);
		
		return opt;
	}

	@Override
	public void deleteProduct(Long id) {
		// TODO Auto-generated method stub
		
	}
		
	
}
