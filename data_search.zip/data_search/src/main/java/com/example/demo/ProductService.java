package com.example.demo;

import java.util.Optional;

import org.springframework.data.domain.Page;

public interface ProductService {

	
	public Page<Product> listAll(int pageNum, String field, String type,String keyword);
	public Product saveProduct(Product product);
	public Product getProduct(Long id);
	
	public Optional<Product> getProductById(Long id);
	public void deleteProduct(Long id);
	
}
